﻿namespace MyClassLibrary
{
  public enum ImportantEnum
  {
    White,
    Red,    //0
    Green,  //1
    Orange  //2
  }
}
