﻿namespace MyClassLibrary
{
    public class Helpers
    {
      public const int WaitTime = 19;
    }
}
