﻿using System;

namespace MyInterfaces
{
    [AttributeUsage(AttributeTargets.Class)]
    public class DoSomethingAttribute : Attribute
    {
    }
}
