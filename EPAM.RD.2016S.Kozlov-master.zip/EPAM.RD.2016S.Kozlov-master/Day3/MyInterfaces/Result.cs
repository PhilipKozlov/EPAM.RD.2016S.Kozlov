﻿using System;

namespace MyInterfaces
{
    [Serializable]
    public class Result
    {
        public int Value { get; set; }
    }
}
