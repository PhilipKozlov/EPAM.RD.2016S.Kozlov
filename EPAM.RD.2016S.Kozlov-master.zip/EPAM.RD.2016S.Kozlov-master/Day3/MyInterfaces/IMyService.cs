﻿namespace MyInterfaces
{
    public interface IDoSomething
    {
        Result DoSomething(Input data);
    }
}
