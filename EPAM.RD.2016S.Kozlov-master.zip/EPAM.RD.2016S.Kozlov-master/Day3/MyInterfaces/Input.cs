﻿using System;

namespace MyInterfaces
{
    [Serializable]
    public class Input
    {
        public User[] Users { get; set; }
    }
}
