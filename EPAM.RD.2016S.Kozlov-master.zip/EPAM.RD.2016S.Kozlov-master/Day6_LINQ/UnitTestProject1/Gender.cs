﻿namespace UnitTestProject1
{
    public enum Gender
    {
        Man =1,
        Female = 2
    }
}
